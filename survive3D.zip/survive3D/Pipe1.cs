using Godot;
using System;

public class Pipe1 : Spatial
{
	// Declare member variables here. Examples:
	// private int a = 2;
	// private string b = "text";

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		Translate(new Vector3(0f, (float)GD.RandRange(-3f, 0f), 0f));	
	}
 
	public override void _Process(float delta)
	{
		Translate(new Vector3(0f, 0f, 4 * delta));
   }
}


	void _on_Pipe1_body_entered(PhysicsBody body)
{
 	if(body.Name == "Bidr"){
		GetTree().ReloadCurrentScene();
	}
}


	void _on_Pipe1_body_entered(PhysicsBody body)
{
	if(body.Name == "Bidr"){
		GetTree().ReloadCurrentScene();
	}
}
