using Godot;
using System;

public class GamePlayer.new_script.gd : Node
{
	private Timer timer;
	
	
	// Declare member variables here. Examples:
	// private int a = 2;
	// private string b = "text";

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		timer = GetNode<Timer>("Timer");
	}
 
}


private void _on_Timer_timeout()
{
 //timer.Start();
PackedScene pipePrefab = ResourceLoader.Load("res://Pipes.tscn") as PackedScene;
	Spatial newPipe = pipePrefab.Instance() as Spatial;
	newPipe.Translation = new Vector3(0f, 0f, -35f);
	AddChild(newPipe);

}
