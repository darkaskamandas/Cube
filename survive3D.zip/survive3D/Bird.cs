using Godot;
using System;

public class Bird : RigidBody
{
	 
	public override void _Ready()
	{
		 
	}
 
	{
		 if(Input.IsActionJustPressed("space")){
			Vector3 temp = LinearVelocity;
			temp.y = 300 * delta;
			LinearVelocity = temp;
		}
	}
}
